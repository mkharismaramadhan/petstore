
/**
 * Write a description of class Food here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Food extends Item
{
    private int weight;
    private boolean isVegetarian;
    private FoodCategory category;

    public Food (int id, String name, int price, int stock, FoodCategory category, int weight, boolean isVegetarian) {
        super(id, name, price, stock);
        this.category = category;
        this.weight = weight;
        this.isVegetarian = isVegetarian;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }

    /**
     * @param isVegetarian the isVegetarian to set
     */
    public void setVegetarian(boolean isVegetarian) {
        this.isVegetarian = isVegetarian;
    }
    
    /**
     * @param isVegetarian the isVegetarian to set
     */
    public void setCategory(FoodCategory category) {
        this.category = category;
    }

    /**
     * @return the weight
     */
    public int getWeight() {
        return weight;
    }

    /**
     * @return the isVegetarian
     */
    public boolean getIsVegetarian() {
        return true;
    }
    
    /**
     * @return the isVegetarian
     */
    public FoodCategory category() {
        return category;
    }

    public String toString() {
      String string="==========FOOD=======";
        string += "\nID ="+getId();
        string += "\nName =" + getName();
        string += "\nPrice: " + getPrice();
        string += "\nStock: " + getStock();
        string += "\nWeight: " + getWeight();
        string += "\nVegetarian: " + getIsVegetarian();
        return string;   
    }
}

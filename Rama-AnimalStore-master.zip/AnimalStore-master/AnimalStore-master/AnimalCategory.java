
/**
 * Enumeration class AnimalCategory - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum AnimalCategory
{
     Dog {
        public String toString() {
            return "Dog";
        }
    }, 
    
    Cat {
        public String toString() {
            return "Cat";
        }
    },
    
    Rabbit {
        public String toString() {
            return "Rabbit";
        }
    },
    
     Turtle {
        public String toString() {
            return "Turtle";
        }
    }, 
    
    Lizard {
        public String toString() {
            return "Lizard";
        }
    },
    
    Bird {
        public String toString() {
            return "Bird";
        }
    }
}

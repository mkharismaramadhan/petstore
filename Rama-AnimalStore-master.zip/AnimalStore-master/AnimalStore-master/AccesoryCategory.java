
/**
 * Enumeration class AccesoryCategory - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum AccesoryCategory
{
   Necklace {
        public String toString() {
            return "Necklace";
        }
    }, 
    
    Costume {
        public String toString() {
            return "Costume";
        }
    },
    
    NameTag {
        public String toString() {
            return "Name Tag";
        }
    },
    
     Toy {
        public String toString() {
            return "Toy";
        }
    }
}


/**
 * Write a description of class Accessory here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Accessory extends Item
{
    private String type;
    private AccesoryCategory category;

    public Accessory (int id, String name, int price, int stock, AccesoryCategory categpry, String type) {
        super(id, name, price, stock);
        this.category = category;
        this.type = type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    
    /**
     * @param type the type to set
     */
    public void setCategory(AccesoryCategory category) {
        this.category = category;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    
    /**
     * @return the type
     */
    public AccesoryCategory category() {
        return category;
    }

    public String toString() {
      String string="==========ACESSORY=======";
        string += "\nID ="+getId();
        string += "\nName =" + getName();
        string += "\nPrice: " + getPrice();
        string += "\nStock: " + getStock();
        string += "\nType: " + getType();
        return string;   
    }
}


/**
 * Enumeration class FoodCategory - write a description of the enum class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public enum FoodCategory
{
    CatFood {
        public String toString() {
            return "Cat Food";
        }
    }, 
    
    DogFood {
        public String toString() {
            return "Dog Food";
        }
    },
    
    RabbitFood {
        public String toString() {
            return "Rabbit Food";
        }
    },
    
     TurtleFood {
        public String toString() {
            return "Turtle Food";
        }
    }, 
    
    LizardFood {
        public String toString() {
            return "Lizard Food";
        }
    },
    
    BirdFood {
        public String toString() {
            return "Bird Food";
        }
    }
}
